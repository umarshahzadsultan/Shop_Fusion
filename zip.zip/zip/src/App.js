import React from 'react'
import Nav from './nav'


function App() {
  return (
   <>
   <Nav/>
   </>
  )
}

export default App